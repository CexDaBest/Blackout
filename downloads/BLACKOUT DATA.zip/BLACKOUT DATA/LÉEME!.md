# **GRACIAS POR DESCARGAR BLACKOUT**

# 

### Blackout es un juego hecho en PowerPoint.

### Esquiva bloques y termina el juego. Simple, *¿verdad?*

# 

# **ANTES DE COMENZAR**

# 

### **Para jugar al juego:**

### 1\. Ve a "**Presentación con diapositivas**" en la barra del menú superior.

### 2\. Selecciona "**Ensayar intervalos**".

# 

# **¿POR QUÉ?**

# 

### \* Esto hace que al morir los niveles se reseteen correctamente.

### \* Si usas otra función (como "Desde el principio") pueden ocurrir errores:

### \- Los niveles no se resetean.

### \- Las diapositivas se pasan solas.

### \- El juego pierde fluidez.

# 

# **CRÉDITOS**

# 

### \* **Cex**: Ejecutador de animaciones, funciones, diseño, etc.

# 

# **NOTA**

# 

### \* El juego está optimizado para funcionar en PowerPoint.

### \* Recuerda siempre iniciar con "Ensayar intervalos" para la mejor experiencia.

### \* Recuerda evitar saltarte partes con el botón de avanzar diapositiva, aunque hayas muerto varias veces puedes estar perdiéndote pedazos de lore, easter eggs, etc.

### \* **Habilita los Macros**, es una función vital para el juego

### 

